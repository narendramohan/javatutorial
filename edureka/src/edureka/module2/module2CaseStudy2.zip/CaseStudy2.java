package edureka.module2;

public class CaseStudy2 {
	public static void main(String[] args) {
		Phone phone = new Phone();
		Mobile  mobile = new Mobile();
		
		phone.makeCall("18923912");
		phone.recieveCall("12832681");
		
		mobile.makeCall("18923912");
		mobile.recieveCall("12832681");
		mobile.createMessage("1234123");
		mobile.readMessage("2312312");
	}
}
