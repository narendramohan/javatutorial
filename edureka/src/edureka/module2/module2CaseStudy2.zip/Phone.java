package edureka.module2;

public class Phone {
	
	public void makeCall(String phoneNumber) {
		System.out.println("Calling to the "+phoneNumber);

	}

	
	public void recieveCall(String phoneNumber) {
		System.out.println("Calling to the "+phoneNumber);

	}
}
